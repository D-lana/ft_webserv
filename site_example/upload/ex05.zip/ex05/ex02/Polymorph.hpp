#ifndef POLYMORPH_HPP
# define POLYMORPH_HPP

# include <iostream>
# include "ASpell.hpp"

class ATarget;

class Polymorph : public ASpell{

	public:
		Polymorph();
		virtual ~Polymorph();

		const std::string& getName() const;
		const std::string& getEffects() const;

		virtual ASpell* clone() const;
		void launch(const ATarget& target);

	private:
		std::string name;
		std::string effects;

};

#endif