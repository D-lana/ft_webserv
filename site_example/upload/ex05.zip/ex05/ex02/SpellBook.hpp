#ifndef SPELLBOOK_HPP
# define SPELLBOOK_HPP

//# include "Warlock.hpp"
# include "ASpell.hpp"
# include "ATarget.hpp"

# include <map>

class SpellBook {

	public:
		SpellBook();
		~SpellBook();

		void learnSpell(ASpell* spell);
		void forgetSpell(std::string const & spellName);
		ASpell* createSpell(std::string const & spellName);

	private:
		std::map<std::string, ASpell*> spells;

};


#endif