#ifndef WARLOCK_HPP
# define WARLOCK_HPP

# include <iostream>
# include <map>

# include "ASpell.hpp"
# include "ATarget.hpp"
# include "SpellBook.hpp"

class Warlock {

	public:
		Warlock(const std::string& _name, const std::string& _title);
		virtual ~Warlock();

		const std::string& getName() const;
		const std::string& getTitle() const;
		void setTitle(const std::string& _title);
		void introduce() const;

		void learnSpell(ASpell* spell);
		void forgetSpell(const std::string& spellName);
		void launchSpell(const std::string& spellName, const ATarget& target);
	
	private:
		std::string name;
		std::string title;

		SpellBook spellbook;

};

#endif