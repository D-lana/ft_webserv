#ifndef FIREBALL_HPP
# define FIREBALL_HPP

# include <iostream>
# include "ASpell.hpp"

class ATarget;

class Fireball : public ASpell{

	public:
		Fireball();
		virtual ~Fireball();

		const std::string& getName() const;
		const std::string& getEffects() const;

		virtual ASpell* clone() const;
		void launch(const ATarget& target);

	private:
		std::string name;
		std::string effects;

};

#endif