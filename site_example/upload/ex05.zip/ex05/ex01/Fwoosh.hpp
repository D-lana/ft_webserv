#ifndef FWOOSH_HPP
# define FWOOSH_HPP

# include <iostream>
# include "ASpell.hpp"

class ATarget;

class Fwoosh : public ASpell{

	public:
		Fwoosh();
		virtual ~Fwoosh();

		const std::string& getName() const;
		const std::string& getEffects() const;

		virtual ASpell* clone() const;
		void launch(const ATarget& target);

	private:
		std::string name;
		std::string effects;

};

#endif