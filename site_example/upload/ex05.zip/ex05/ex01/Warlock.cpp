#include "Warlock.hpp"

Warlock::Warlock(const std::string& _name, const std::string& _title) : name(_name), title(_title)
{
	std::cout << name << ": This looks like another boring day." << std::endl;
}

Warlock::~Warlock()
{
	std::cout << name << ": My job here is done!" << std::endl;
}

const std::string& Warlock::getName() const
{
	return (name);
}

const std::string& Warlock::getTitle() const
{
	return (title);
}

void Warlock::setTitle(const std::string& _title)
{
	title = _title;						
}

void Warlock::introduce() const
{
	std::cout << name << ": I am " << name << ", " << title << "!" << std::endl;
}

void Warlock::learnSpell(const ASpell* spell)
{
	if (spell)
		spells.insert(std::pair<std::string, ASpell*> (spell->getName(), spell->clone()));
	

}

void Warlock::forgetSpell(const std::string& spellName)
{
	std::map<std::string, ASpell*>::iterator it = spells.find(spellName);
	if (it != spells.end())
		spells.erase(it); // erase(spellName)
}

void Warlock::launchSpell(const std::string& spellName, const ATarget& target)
{
	std::map<std::string, ASpell*>::iterator it = spells.find(spellName);
	if (it != spells.end())
		spells[spellName]->launch(target);
}