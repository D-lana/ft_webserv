#ifndef WARLOCK_HPP
# define WARLOCK_HPP

# include <iostream>

class Warlock {

	public:
		Warlock(const std::string& _name, const std::string& _title);
		virtual ~Warlock();

		const std::string& getName() const;
		const std::string& getTitle() const;
		void setTitle(const std::string& _title);
		void introduce() const;

	
	private:
		std::string name;
		std::string title;

};

#endif